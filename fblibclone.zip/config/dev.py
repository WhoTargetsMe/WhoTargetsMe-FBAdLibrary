DEBUG=True
SECRET_KEY='mysecret'
SQLALCHEMY_DATABASE_URI='postgresql://evgenia:12345@localhost/fblibclone'
SQLALCHEMY_TRACK_MODIFICATIONS=False
APP_ID='1969644276620014'
APP_SECRET='8f12eb11035256f47ed1be33974967a6'
API_VERSION='3.1'
# moved to db
# LONG_TOKEN='EAAbZCYYtxGu4BAJy9FubXICjw6eYrY3vw6YVGU5t3haccscdDEcMF8NvEf9vCcLHE1gHdxfp4R51LLF5kdde4qv6zIP7uu6MPiclQaMCcr6f98XEVqyAvPZBNhZAIobrp5dOf5cgJtMXCQSRdVZBIf1MM3i7ZAYGvFvuIIBuUnwZDZD'
# LONG_TOKEN_EXPIRES_IN=5184000

# How many pages we want to fetch between each storing operation
PAGES_BETWEEN_STORING = 10
# Each page may contain 25-5000 ads, but tests show that they don't permit to fetch 5000
ADS_PER_PAGE = 500
# Interval of cron job in seconds, default - 1 day
INTERVAL = 3600*24
